# LSP Server Configuration

**Total Servers:** 1

---

## 🔧 LowLevel

### `rust_analyzer`

- **File:** `lua/user/config/server/LowLevel/rust_analyzer.lua`
- **Command:** `"rust-analyzer"`
- **Filetypes:** `"rust"`

