# Plugin Inventory

**Total Unique Plugins:** 3

---

## `folke/lazy.nvim`

**Repository:** https://github.com/folke/lazy.nvim

**Referenced in 2 file(s):**

- `lua/user/stages/01_test.lua`

## `neovim/nvim-lspconfig`

**Repository:** https://github.com/neovim/nvim-lspconfig

**Referenced in 1 file(s):**

- `lua/user/stages/01_test.lua`

## `nvim-treesitter/nvim-treesitter`

**Repository:** https://github.com/nvim-treesitter/nvim-treesitter

**Referenced in 1 file(s):**

- `lua/user/stages/01_test.lua`

