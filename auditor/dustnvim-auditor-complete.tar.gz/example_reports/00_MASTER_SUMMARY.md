# DustNvim Configuration Audit

**Generated:** 2026-01-28 04:16:17

---

## 📊 Quick Stats

| Metric | Count |
|--------|------:|
| Unique Plugins | 3 |
| Total Plugin References | 4 |
| Keybindings | 3 |
| Functions | 0 |
| LSP Servers | 1 |

## ⚠️ Issues Found

- **Duplicate Plugins:** 1
- **Duplicate Functions:** 0
- **Duplicate Keybindings:** 0

## 📚 Report Index

1. [Plugin Inventory](01_PLUGINS.md)
2. [Keybinding Reference](02_KEYBINDINGS.md)
3. [Duplicate Detection](03_DUPLICATES.md)
4. [LSP Servers](04_LSP_SERVERS.md)

