# Duplicate Detection

---

## ⚠️ Duplicate Plugin Declarations

### `folke/lazy.nvim` (2 occurrences)

- `lua/user/stages/01_test.lua`
- `lua/user/stages/01_test.lua`

## ⚠️ Duplicate Function Definitions

✅ No duplicate function definitions found!

## ⚠️ Duplicate Keybindings

✅ No duplicate keybindings found!

